# Akatsuki - A mini server based realtime chat application.
#### Video Demo:  https://youtu.be/6q1tMgVhcds
#### Description:

objective; to build a community of loners / intoverts where like-minded conect , share thoughts and learn from each other.
 we talk about life-talks, money andd fitness [3 channels proposed]
this is a discord-like application, with server and channels (currently it has single channel).

strucutere:

server : channel 1,....

####tech stack :  Flask(Python) => backend
               broad casting messages => Flask socket io
               frontend / client side : HTML,CSS , JS
               database [local] : SQLITE

####key functionalities:

=> realtime chats
=> group setup as a channel
=> loading chat history when anyone joins the chat.
=> login user
=> register user
=> logout


####future scope functionalities:
=> AI chat bot integration
=> e_id and contribution level (XP)
=> shareablke media along with chats.
=> token validation
=> SSL validation for signing in

******************************************************************************

#1. App.py : 

this is the controller code or the main file for my program/ application where all the route are being defned.

this is where the flask is setup, the database and the websockets is configured along with session configuratyion

there are several routes in the app.py. 


When a user hits the site at '/'' or '/about', they land on a clean intro page — about.html,  welcome screen. 

If they click on Register, and it’s a GET request, they see the form to sign up.
 Once they submit it (POST), the app grabs their age, token, password, and country, hashes the password using Bcrypt, and saves all that in the users table with a custom username like "akatsuki_member123".
 Then it confirms the user is in by rendering the server.html — your main app page, passing their name to greet them.


 Now if they go to /login, they either get the login form (GET) or, if they POST the form, the backend checks if that token exists and if the password matches the hashed one. If all checks out, boom — they're in and redirected to server.html. If not, they land on your apology.html page — probably a chill “wrong creds” vibe.

The /logout route clears their session and kicks them back to about.html. 


## broadcasting messages.

when someone joins the chat, the join event is triggered, puts them in their own room using their username, then sends a “user joined the chat” message and dumps all previous chat history,
 even showing date separators for old messages.

When someone sends a message (@socketio.on('message')), the app checks if the date has changed — if yes, it drops a new date line and saves that too.

 Then it broadcasts the message to everyone and stores it in the DB. Finally, when a user disconnects, the disconnect event blasts a “user left the chat” message to all.



