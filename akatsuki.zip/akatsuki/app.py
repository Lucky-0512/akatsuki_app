from flask import Flask,render_template,session,redirect, request
from flask_session import Session
from flask_bcrypt import Bcrypt
from cs50 import SQL
from datetime import datetime

from flask_socketio import SocketIO, send, emit, join_room, leave_room  # for websockets using socket IO

app = Flask(__name__)  # initialise a flak app
bcrypt = Bcrypt(app)  # configure bcrypt encryption
db = SQL("sqlite:///data.db")  # configuring database.
socketio = SocketIO(app)

# session config
app.config["SESSION_PERMANENT"] = False     # Sessions expire when the browser is closed
app.config["SESSION_TYPE"] = "filesystem"     # Store session data in files

# Initialize Flask-Session
Session(app)

# token generation.

# yet to be done.....


# route definitions ***************************************

@app.route("/logout")
def logout():
        session.clear()
        return render_template("about.html")

@app.route("/")
def dis():
     return render_template("about.html")



@app.route("/register",methods = ["GET","POST"])
def register():
    if request.method == "GET":
         return render_template("register.html")
    elif request.method == "POST":
        session["age"] = request.form.get("age")
        session["token"] = request.form.get("token")  # check with validated token assigned.
        session["pass"] = request.form.get("pass") 
        session["country"] = request.form.get("country")
                 
        # hashing passsword. 
        hashed_password = bcrypt.generate_password_hash(session["pass"]).decode('utf-8')
        # to insert into the databse, with timestamp.
        username = "akatsuki_member"+session["token"]
        db.execute("INSERT into users(username,age,token_no,pass,country) values(?,?,?,?,?)",username,session["age"],session["token"] ,hashed_password,session["country"])
        fetch_name = db.execute("select username from users where token_no = ?",session["token"])
        name = fetch_name[0]["username"]
        return render_template("server.html",name=name)



        
@app.route("/login",methods = ["POST","GET"])
def login():
     

     if request.method == "GET":
          return render_template("login.html")
     
     elif request.method == "POST":
        
        session['pass'] = request.form.get("pass")
        session['token'] = request.form.get("token")
        user = db.execute("SELECT * FROM users WHERE token_no = ?", session['token'])
        if user and bcrypt.check_password_hash(user[0]['pass'], session['pass']):
            name = user[0]["username"]
            session['username'] = name
            return render_template("server.html", name=name)
     
        else:
            return render_template("apology.html")

@app.route('/about')
def about():
     return render_template("about.html")



# SOCKET IO EVENT HAnDLERS
    
#------------------------------------------------------------
@socketio.on('join')
def handle_join():
    join_name = session["username"]# Store username by session ID
    join_room(join_name)  # Each user gets their own "room"
    emit("message", f"{join_name} joined the chat", room=join_name)
    # render the chat history here.
    messages = db.execute("SELECT username, content, timestamp,type FROM messages ORDER BY id ASC")
    for i in messages:
        if i["type"] == "date":
             emit("message",f" {i['content'] }", room=join_name)
        else:     
     
            emit("message", f"{i['username']}: {i['content']} @ {i['timestamp']}", room=join_name)


last_message_date = None  # get the date of the last entered message in the chatbox.

# Handle user messages
@socketio.on('message')
def handle_message(data):
    global last_message_date
    current_date_str = datetime.now().strftime("%A, %B %d, %Y")  # current msg timestamp
    if last_message_date != current_date_str:
         last_message_date = current_date_str
         emit('message', current_date_str, broadcast=True)
         db.execute(
        "INSERT INTO messages(username, content,type) VALUES(?, ?, ?)",
        "system",  # or "date_separator"
        current_date_str,  # e.g., "Monday, June 10, 2025"
        "date")


    else:
         
        emit("message", f"{session['username']}: {data}", broadcast=True)  # Send to everyone
        # store it in the database table called "messages."
        db.execute("INSERT INTO messages(username,content) values(?,?)",session['username'],data)


# Handle disconnects
@socketio.on('disconnect')
def handle_disconnect():
    emit("message", f"{session['username']} left the chat", broadcast=True)

if __name__ == '__main__':
    socketio.run(app, debug=True)